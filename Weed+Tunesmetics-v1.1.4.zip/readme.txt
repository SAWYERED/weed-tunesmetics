Thanks for playing with Weed+Tunesmetics!
Weed+Tunes Dedicated C- erm... Server Cosmetics! Adds Titles and Colors, + Alien Cosmetics. [wave]glorpa gazoopa ! nonglorpians are all the same - zubiza zub zub see us coming. LMGO
Version: 1.1.4
Authors: SAWYERED
https://github.com/SAWYERED/WEBFISHING-WEED-N-TUNES-MODPACK

This mod was made with Hatchery 1.3.2
https://github.com/coolbot100s/Hatchery